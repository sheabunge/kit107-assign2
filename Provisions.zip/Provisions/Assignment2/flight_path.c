// KIT107 Assignment 2: Flight Path
/*
* Implementation for Flight Path
* Author <<YOUR STUDENT ID AND NAME HERE>>
* Version <<DATE>>
*/

#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "flight_path.h"
//COMPLETE ME!!